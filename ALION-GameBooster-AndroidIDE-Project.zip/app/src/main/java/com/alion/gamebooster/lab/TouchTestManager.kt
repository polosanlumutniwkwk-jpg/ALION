package com.alion.gamebooster.lab

import android.view.MotionEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.hypot

/**
 * Game Lab Touch Screen Diagnostic Engine.
 * Tests touch polling rate, multi-touch tracking, dead zones, and touch latency.
 */
class TouchTestManager {

    data class TouchPointer(
        val id: Int,
        val x: Float,
        val y: Float,
        val pressure: Float,
        val size: Float,
        val timestampNano: Long
    )

    private val _activePointers = MutableStateFlow<Map<Int, TouchPointer>>(emptyMap())
    val activePointers: StateFlow<Map<Int, TouchPointer>> = _activePointers.asStateFlow()

    private val _maxConcurrentTouches = MutableStateFlow(0)
    val maxConcurrentTouches: StateFlow<Int> = _maxConcurrentTouches.asStateFlow()

    private var previousEventTimeNano: Long = 0
    private val intervals = mutableListOf<Long>()

    fun processMotionEvent(event: MotionEvent) {
        val pointerMap = mutableMapOf<Int, TouchPointer>()
        val count = event.pointerCount

        if (count > _maxConcurrentTouches.value) {
            _maxConcurrentTouches.value = count
        }

        val nowNano = System.nanoTime()
        if (previousEventTimeNano > 0) {
            val deltaNano = nowNano - previousEventTimeNano
            if (deltaNano > 0) {
                intervals.add(deltaNano)
                if (intervals.size > 100) intervals.removeAt(0)
            }
        }
        previousEventTimeNano = nowNano

        for (i in 0 until count) {
            val pointerId = event.getPointerId(i)
            pointerMap[pointerId] = TouchPointer(
                id = pointerId,
                x = event.getX(i),
                y = event.getY(i),
                pressure = event.getPressure(i),
                size = event.getSize(i),
                timestampNano = event.eventTime * 1_000_000
            )
        }

        if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
            _activePointers.value = emptyMap()
        } else {
            _activePointers.value = pointerMap
        }
    }

    /**
     * Calculates empirical touch sampling frequency in Hz
     */
    fun calculateSampleRateHz(): Int {
        if (intervals.isEmpty()) return 240
        val avgNano = intervals.average()
        return if (avgNano > 0) (1_000_000_000.0 / avgNano).toInt().coerceIn(60, 1000) else 240
    }

    /**
     * Distance offset calculation for precision test
     */
    fun calculateTouchOffsetPx(targetX: Float, targetY: Float, actualX: Float, actualY: Float): Float {
        return hypot(targetX - actualX, targetY - actualY)
    }
}