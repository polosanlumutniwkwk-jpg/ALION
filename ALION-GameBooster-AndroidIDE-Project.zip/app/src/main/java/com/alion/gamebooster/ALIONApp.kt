package com.alion.gamebooster

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.alion.gamebooster.engine.PerformanceEngine
import com.alion.gamebooster.shizuku.ShizukuManager

/**
 * ALION Application entry point.
 * Initializes Performance Engine, Shizuku bindings, and notification channels.
 */
class ALIONApp : Application() {

    companion object {
        lateinit var instance: ALIONApp
            private set
        
        const val OVERLAY_CHANNEL_ID = "alion_overlay_service_channel"
        const val THERMAL_ALERT_CHANNEL_ID = "alion_thermal_alert_channel"
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        createNotificationChannels()
        PerformanceEngine.init(this)
        ShizukuManager.init()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)

            val overlayChannel = NotificationChannel(
                OVERLAY_CHANNEL_ID,
                "ALION Game HUD Active",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows persistent status while floating game overlay is active"
                setShowBadge(false)
            }

            val thermalChannel = NotificationChannel(
                THERMAL_ALERT_CHANNEL_ID,
                "ALION Thermal Safeguard",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts when device thermal throttle or high temperature occurs"
                enableVibration(true)
            }

            notificationManager.createNotificationChannel(overlayChannel)
            notificationManager.createNotificationChannel(thermalChannel)
        }
    }
}