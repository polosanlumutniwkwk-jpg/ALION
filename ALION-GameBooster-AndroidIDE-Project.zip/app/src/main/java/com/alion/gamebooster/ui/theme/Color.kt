package com.alion.gamebooster.ui.theme

import androidx.compose.ui.graphics.Color

object AlionColors {
    val ElectricBlue = Color(0xFF00D2FF)
    val NeonCyan = Color(0xFF00F0FF)
    val DeepNavy = Color(0xFF050B14)
    val SurfaceDark = Color(0xFF0A111E)
    val SurfaceLight = Color(0xFF101C2E)
    val BorderDark = Color(0xFF16263D)
    val AccentGreen = Color(0xFF00E676)
    val WarningAmber = Color(0xFFFFB300)
    val AlertRed = Color(0xFFFF3366)
    val TextPrimary = Color(0xFFF1F5F9)
    val TextSecondary = Color(0xFF94A3B8)
    val TextMuted = Color(0xFF64748B)
    val BackgroundDark = Color(0xFF030712)
}