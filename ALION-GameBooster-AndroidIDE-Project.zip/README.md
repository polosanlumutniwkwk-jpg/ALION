# ALION - Android Game Booster & Performance Engine

ALION adalah aplikasi Android Game Booster profesional berbasis Kotlin & Jetpack Compose.
Didesain untuk dapat di-build baik di **Android Studio (PC)** maupun langsung di HP menggunakan **AndroidIDE**.

---

## 📱 PANDUAN BUILD DI HP DENGAN AndroidIDE (Tanpa PC)

AndroidIDE adalah IDE lengkap yang berjalan langsung di sistem Android. Anda dapat meng-compile aplikasi ALION menjadi APK langsung dari smartphone Anda!

### Langkah-langkah:
1. **Download Aplikasi AndroidIDE**:
   - Unduh dari situs resmi: [https://androidide.com](https://androidide.com) atau via F-Droid / GitHub Releases.
2. **Download & Ekstrak Proyek ALION**:
   - Unduh file ZIP proyek ALION dari web ini (`ALION-GameBooster-Android-Studio-Project.zip`).
   - Ekstrak file ZIP menggunakan aplikasi pengelola file (ZArchiver, Files, dll.) ke folder:
     `/storage/emulated/0/AndroidIDEProjects/ALION`
3. **Buka Proyek di AndroidIDE**:
   - Buka aplikasi **AndroidIDE**.
   - Pilih menu **Open Project** -> Cari dan pilih folder **ALION**.
   - AndroidIDE akan mendeteksi Gradle Kotlin DSL dan melakukan **Gradle Sync** otomatis.
4. **Compile APK**:
   - Cara 1 (GUI): Klik tombol **Run / Build** (ikon Play segitiga hijau) di bagian atas AndroidIDE.
   - Cara 2 (Terminal): Buka tab **Terminal** di AndroidIDE, lalu ketik perintah:
     ```bash
     chmod +x gradlew
     ./gradlew assembleDebug
     ```
5. **Install APK**:
   - File APK Debug akan selesai dibuat di:
     `app/build/outputs/apk/debug/app-debug.apk`
   - AndroidIDE akan menampilkan pop-up untuk langsung meng-install APK tersebut di HP Anda.

---

## 💻 PANDUAN BUILD DI PC DENGAN ANDROID STUDIO

1. Buka Android Studio (Ladybug 2024.2+ atau Meerkat).
2. Pilih **File > Open**, pilih folder proyek ALION ini.
3. Tunggu proses Gradle Sync selesai.
4. Jalankan perintah di Terminal:
   ```bash
   ./gradlew assembleDebug
   ```
5. Untuk Release APK (Production):
   ```bash
   ./gradlew assembleRelease
   ```

---

## ⚡ FITUR UNGGULAN ALION
- **Home Dashboard**: Telemetri CPU Cortex-X4/A720/A520, GPU Adreno 750, LPDDR5X RAM, zRAM, Suhu Baterai, dan Refresh Rate.
- **Game Space**: Profil game otomatis (Ultra Response, Performance, Balanced, Eco).
- **Graphics Control**: DisplayManager 60Hz/90Hz/120Hz/144Hz, WindowManager scaling, dan Shizuku ADB commands.
- **Floating HUD Overlay**: Overlay melayang di atas game dengan FPS, CPU %, RAM, Suhu, Ping, dan Custom Crosshair.
- **Game Lab**: Uji Multi-touch, Akurasi Sentuhan, Deadzone joystick, dan Ghost Touch scanner.
- **Shizuku & Wireless Debugging**: Fitur tingkat lanjut tanpa perlu root HP.
